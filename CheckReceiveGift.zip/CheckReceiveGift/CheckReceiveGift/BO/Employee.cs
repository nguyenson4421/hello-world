﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckReceiveGift
{
    public class Employee
    {
        /// <summary>
        /// Mã
        /// </summary>
        public string EmployeeCode { get; set; }

        /// <summary>
        /// Họ tên
        /// </summary>
        public string EmployeeName { get; set; }

        /// <summary>
        /// Thuộc về
        /// </summary>
        public string Section { get; set; }

        /// <summary>
        /// Phòng ban
        /// </summary>
        public string Department { get; set; }

        /// <summary>
        /// Công đoàn
        /// </summary>
        public string Union { get; set; }

        /// <summary>
        /// Ngày sinh
        /// </summary>
        public string Birthday { get; set; }

        /// <summary>
        /// Quà hay chuyển khoản
        /// </summary>
        public string Gift { get; set; }

        /// <summary>
        /// Trạng thái: 0 - chưa nhận quà, 1 - đã nhận quà, 2 - ko có trong danh sách nhận, 3 - lấy all(ko lấy status = 2)
        /// </summary>
        public Enum.EmployeeStatus Status { get; set; }
        
        /// <summary>
        /// Thời gian nhận quà
        /// </summary>
        public DateTime ReceivedTime { get; set; }

        /// <summary>
        /// Số lần check (khi vượt quá 1 lần check)
        /// </summary>
        public string Times { get; set; }

        /// <summary>
        /// Nhà máy
        /// </summary>
        public string Company { get; set; }
    }
}
