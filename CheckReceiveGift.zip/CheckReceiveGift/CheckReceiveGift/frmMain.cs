﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using OfficeOpenXml;

namespace CheckReceiveGift
{
    /// <summary>
    /// PM check thẻ người lao động để phát quà
    /// Created by: SONNT - 03/01/2022
    /// </summary>
    public partial class frmMain : Form
    {
        //Nhà máy làm việc
        string company = "";

        public frmMain()
        {
            InitializeComponent();
            string sCompany = Utilitis.GetAppSetingKeys("Company");
            string sEnableImport = Utilitis.GetAppSetingKeys("EnableImport");
            int iEnableImport = 0;
            int.TryParse(sEnableImport, out iEnableImport);

            if (!string.IsNullOrEmpty(sCompany))
            {
                lblCompany.Text = sCompany.ToString();
                lblCompany.Visible = true;
                company = sCompany;
                RefreshData();
                this.ActiveControl = lblResult;

                if (iEnableImport == 1)
                {
                    btnImportEmployee.Enabled = true;
                }
                else
                {
                    btnImportEmployee.Enabled = false;
                    btnImportEmployee.BackColor = Color.Gray;
                }
            }
            else
            {
                MessageBox.Show("Chưa chọn nhà máy làm việc!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Application.Exit();
            }
        }

        /// <summary>
        /// Nút tìm kiếm
        /// </summary>
        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                dgvNotReceived.Focus();//trick: để bắt sk keypreview quét barcode
                RefreshData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Nhập tại ô tìm kiếm, nhấn Enter thì tìm kiếm
        /// </summary>
        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                //if (e.KeyCode == Keys.Enter)
                //{
                //    RefreshData();
                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// SK refresh
        /// </summary>
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            try
            {
                dgvNotReceived.Focus();//trick: để bắt sk keypreview quét barcode
                RefreshData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Làm mới dữ liệu
        /// </summary>
        private void RefreshData()
        {

            ////progressBar
            //progressBar1.Minimum = 0;
            //progressBar1.Maximum = 10;
            //progressBar1.Visible = true;
            //progressBar1.Value = 8;

            //string sKeySearch = txtSearch.Text;
            //LoadGridReceived(sKeySearch);
            //LoadGridNotReceived(sKeySearch);

            //progressBar1.Value = 10;
            //progressBar1.Visible = false;


            //progressBar
            progressBar1.Minimum = 0;
            progressBar1.Maximum = 10;
            progressBar1.Visible = true;
            progressBar1.Value = 8;

            string sKeySearch = txtSearch.Text;

            Thread t1 = new Thread(() =>
            {
                LoadGridReceived(sKeySearch);
            });
            t1.Start();
            t1.IsBackground = true;

            Thread t2 = new Thread(() =>
            {
                LoadGridNotReceived(sKeySearch);
            });
            t2.Start();
            t2.IsBackground = true;

            progressBar1.Value = 10;
            progressBar1.Visible = false;
        }

        /// <summary>
        /// Load danh sách nhân viên chưa nhận quà
        /// <paramref name="sKeySearch"/>Từ khóa tìm kiếm
        /// </summary>
        private void LoadGridNotReceived([Optional] string sKeySearch)
        {
            try
            {
                List<Employee> lst = new List<Employee>();
                lst = DataProvider.ExcuteReader<Employee>("dbo.Proc_GetEmployee", new object[] { Enum.EmployeeStatus.NotReceived, company, sKeySearch });

                dgvNotReceived.Invoke(new Action(() =>
                {
                    dgvNotReceived.DataSource = null;

                    dgvNotReceived.DataSource = lst;
                    dgvNotReceived.Columns["EmployeeCode"].HeaderText = "Mã";
                    dgvNotReceived.Columns["EmployeeName"].HeaderText = "Họ Tên";
                    dgvNotReceived.Columns["Section"].HeaderText = "Bộ phận";
                    dgvNotReceived.Columns["Department"].HeaderText = "Phòng ban";
                    dgvNotReceived.Columns["Union"].HeaderText = "Công đoàn";
                    dgvNotReceived.Columns["Birthday"].HeaderText = "Ngày sinh";
                    dgvNotReceived.Columns["Company"].Visible = false;
                    dgvNotReceived.Columns["Gift"].Visible = false;
                    dgvNotReceived.Columns["Status"].Visible = false;
                    dgvNotReceived.Columns["ReceivedTime"].Visible = false;
                    dgvNotReceived.Columns["Times"].Visible = false;
                    dgvNotReceived.Columns["EmployeeName"].MinimumWidth = 130;
                    dgvNotReceived.Columns["EmployeeName"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

                    dgvNotReceived.AlternatingRowsDefaultCellStyle.BackColor = Color.AliceBlue;

                    lblNotReceived.Text = (!string.IsNullOrEmpty(sKeySearch) ? "Tìm kiếm " : "") + "Chưa nhận (" + lst.Count() + ")";
                    lblNotReceived.Update();
                }));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Load danh sách nhân viên đã nhận quà
        /// </summary>
        private void LoadGridReceived([Optional] string sKeySearch)
        {
            try
            {
                List<Employee> lst = new List<Employee>();
                lst = DataProvider.ExcuteReader<Employee>("dbo.Proc_GetEmployee", new object[] { Enum.EmployeeStatus.Received, company, sKeySearch });

                dgvReceived.Invoke(new Action(() =>
                {
                    dgvReceived.DataSource = null;

                    dgvReceived.DataSource = lst;
                    dgvReceived.Columns["EmployeeCode"].HeaderText = "Mã";
                    dgvReceived.Columns["EmployeeName"].HeaderText = "Họ Tên";
                    dgvReceived.Columns["Section"].HeaderText = "Bộ phận";
                    dgvReceived.Columns["Department"].HeaderText = "Phòng ban";
                    dgvReceived.Columns["Union"].HeaderText = "Công đoàn";
                    dgvReceived.Columns["Birthday"].HeaderText = "Ngày sinh";
                    dgvReceived.Columns["Company"].Visible = false;
                    dgvReceived.Columns["Gift"].Visible = false;
                    dgvReceived.Columns["Status"].Visible = false;
                    dgvReceived.Columns["ReceivedTime"].HeaderText = "Thời gian nhận";
                    dgvReceived.Columns["Times"].HeaderText = "Vượt quá lần quẹt";

                    dgvReceived.Columns["Times"].Width = 130;
                    dgvReceived.Columns["ReceivedTime"].Width = 130;
                    dgvReceived.Columns["ReceivedTime"].DefaultCellStyle.Format = "HH:mm:ss - dd'/'MM'/'yyyy";

                    dgvReceived.Columns["EmployeeCode"].Width = 60;
                    dgvReceived.Columns["EmployeeName"].MinimumWidth = 130;
                    dgvReceived.Columns["EmployeeName"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

                    dgvReceived.AlternatingRowsDefaultCellStyle.BackColor = Color.AliceBlue;

                    lblReceived.Text = (!string.IsNullOrEmpty(sKeySearch) ? "Tìm kiếm " : "") + "Đã nhận (" + lst.Count() + ")";
                    lblReceived.Update();
                }));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Nhập danh sách người nhận quà
        /// </summary>
        private void btnImportEmployee_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(company))
                {
                    using (OpenFileDialog openfileDialog = new OpenFileDialog() { Filter = "Excel File (.xlx*)|*.xls*" })
                    {
                        if (openfileDialog.ShowDialog() == DialogResult.OK)
                        {
                            lblFileName.Text = openfileDialog.FileName.Split('\\').Last();
                            lblFileName.Visible = true;
                            //Save file in file 

                            string Paths = lblFileName.Text;
                            String filePath = (Paths.Split('\\').Last());

                            string filename = System.IO.Path.GetFileName(filePath);
                            if (filename != null)
                            {
                                var lastPath = filename.Split('.').Last();
                                if (!lastPath.Equals("pdf"))
                                {
                                    using (var stream = File.Open(openfileDialog.FileName, FileMode.Open, FileAccess.Read))
                                    {
                                        using (ExcelPackage package = new ExcelPackage(stream))
                                        {
                                            List<Employee> lstEmployee = new List<Employee>();
                                            //Thực hiện đọc từ InputStream
                                            var ws = package.Workbook.Worksheets["Nhan qua"];

                                            //Bắt đầu đọc từ dòng thứ 2
                                            for (int rw = 2; rw <= ws.Dimension.End.Row; rw++)
                                            {
                                                //Lấy giá trị đang filter
                                                if (!ws.Row(rw).Hidden)
                                                {
                                                    //Chỉ lấy NV có cột Quà là Quà
                                                    if (ws.Cells[rw, 2].Text != "" && ws.Cells[rw, 2].Text != null && ws.Cells[rw, 10].Text != null && ws.Cells[rw, 10].Text.Equals("Quà"))
                                                    {
                                                        lstEmployee.Add(new Employee
                                                        {
                                                            EmployeeCode = ws.Cells[rw, 2].Text != null ? ws.Cells[rw, 2].Text : string.Empty,//Mã
                                                            EmployeeName = ws.Cells[rw, 3].Text != null ? ws.Cells[rw, 3].Text : string.Empty,//Tên
                                                            Section = ws.Cells[rw, 4].Text != null ? ws.Cells[rw, 4].Text : string.Empty,//Thuộc về
                                                            Department = ws.Cells[rw, 5].Text != null ? ws.Cells[rw, 5].Text : string.Empty,//Phòng ban
                                                            Union = ws.Cells[rw, 6].Text != null ? ws.Cells[rw, 6].Text : string.Empty,//Công đoàn
                                                            Gift = ws.Cells[rw, 10].Text != null ? ws.Cells[rw, 10].Text : string.Empty,//Quà
                                                            Birthday = ws.Cells[rw, 13].Text != null ? ws.Cells[rw, 13].Text : string.Empty,//Ngày sinh
                                                            Status = Enum.EmployeeStatus.NotReceived,
                                                            Company = company,//MD
                                                        });
                                                    }
                                                }
                                            }

                                            //Save to database
                                            if (lstEmployee.Count > 0)
                                            {
                                                int countEmployee = lstEmployee.Count;
                                                DialogResult dialogResult = MessageBox.Show("Xác nhận nhập " + countEmployee + " dòng dữ liệu từ file [" + openfileDialog.FileName.Split('\\').Last() + "] ?", "Xác nhận", MessageBoxButtons.YesNo);

                                                if (dialogResult == DialogResult.Yes)
                                                {
                                                    //progressBar
                                                    progressBar1.Minimum = 0;
                                                    progressBar1.Maximum = countEmployee;
                                                    progressBar1.Visible = true;
                                                    lblProgress.Visible = true;

                                                    string sql_temp = "INSERT INTO Employee (EmployeeCode, EmployeeName, Section, Department, [Union], Gift, Birthday, Company) Values ";
                                                    string sql = "";

                                                    for (int i = 0; i < countEmployee; i++)
                                                    {
                                                        if (i == 0)
                                                        {
                                                            //Xóa dữ liệu cũ
                                                            bool result = DataProvider.ExecuteNonQueryByQuerySQL("Delete from Employee where Company = '" + company + "'");
                                                            sql = sql_temp;
                                                        }

                                                        if (i > 0 && ((i + 1) % 1000) != 1)//Ext: 2001
                                                        {
                                                            sql += ",";
                                                        }

                                                        sql += string.Format("(N'{0}', N'{1}', N'{2}', N'{3}', N'{4}', N'{5}', '{6}', N'{7}')", lstEmployee[i].EmployeeCode, lstEmployee[i].EmployeeName, lstEmployee[i].Section, lstEmployee[i].Department, lstEmployee[i].Union, lstEmployee[i].Gift, lstEmployee[i].Birthday, company);

                                                        //Tối đa 1000 dòng/lần
                                                        if (((i + 1) % 1000) == 0 || i == countEmployee - 1)
                                                        {
                                                            //Save to database
                                                            bool result = DataProvider.ExecuteNonQueryByQuerySQL(sql);
                                                            sql = sql_temp;
                                                        }

                                                        progressBar1.Value = i;
                                                        lblProgress.Text = (i + 1) + "/" + countEmployee;
                                                        lblProgress.Update();
                                                    }

                                                    LoadGridNotReceived();
                                                    LoadGridReceived();

                                                    MessageBox.Show("Import thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                    progressBar1.Visible = false;
                                                    lblProgress.Visible = false;
                                                }
                                                else
                                                {
                                                    lstEmployee = null;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show("Document invalid!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Chưa chọn nhà máy làm việc!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                lblFileName.Visible = false;
                dgvNotReceived.Focus();//trick: để bắt sk keypreview quét barcode
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //CommonFunctionLogging.HandleException(ex);
            }
        }

        /// <summary>
        /// Xuất danh sách các thông tin (đã nhận, chưa nhận, có check nhưng ko có trong danh sách)
        /// </summary>
        private void btnExport_Click(object sender, EventArgs e)
        {
            string templatefilename = "Report/Template/Report_Template.xls";
            string filename = "Report/Report_" + DateTime.Now.ToString("ddMMyyyyHHmmss") + ".xlsx";

            try
            {
                if (File.Exists(filename))
                    File.Delete(filename);

                using (var file = new FileStream(filename, FileMode.CreateNew))
                {
                    using (var temp = new FileStream(templatefilename, FileMode.Open))
                    {
                        using (var xls = new ExcelPackage(file, temp))
                        {
                            List<Employee> lst = new List<Employee>();
                            lst = DataProvider.ExcuteReader<Employee>("dbo.Proc_GetEmployee", new object[] { Enum.EmployeeStatus.All, company, null });

                            if (lst.Count > 0)
                            {
                                //Đã nhận
                                List<Employee> lstReceived = lst.Where(d => d.Status == Enum.EmployeeStatus.Received).ToList();
                                if (lstReceived.Count > 0)
                                {
                                    ExcelWorksheet ws = xls.Workbook.Worksheets["Đã nhận"];
                                    int row = 2;// dòng bắt đầu ghi dữ liệu
                                    foreach (var item in lstReceived)
                                    {
                                        ws.Cells[string.Format("A{0}", row)].Value = (row - 1);//STT
                                        ws.Cells[string.Format("B{0}", row)].Value = item.EmployeeCode;//Mã
                                        ws.Cells[string.Format("C{0}", row)].Value = item.EmployeeName;//Tên
                                        ws.Cells[string.Format("D{0}", row)].Value = item.Section;//Bộ phận
                                        ws.Cells[string.Format("E{0}", row)].Value = item.Department;//Phòng ban
                                        ws.Cells[string.Format("F{0}", row)].Value = item.Union;//Công đoàn
                                        ws.Cells[string.Format("G{0}", row)].Value = !string.IsNullOrEmpty(item.Birthday) ? item.Birthday.ToString() : "";//Ngày sinh
                                        ws.Cells[string.Format("H{0}", row)].Value = (item.ReceivedTime != null && item.ReceivedTime != DateTime.MinValue) ? item.ReceivedTime.ToString("HH:mm:ss - dd/MM/yyyy") : "Null";//Thời gian nhận quà
                                        ws.Cells[string.Format("I{0}", row)].Value = item.Company;//Nhà máy nhận quà
                                        ws.Cells[string.Format("J{0}", row)].Value = item.Times;//Vượt quá lần quẹt
                                        row++;
                                    }
                                }

                                //Chưa nhận
                                List<Employee> lstNotReceived = lst.Where(d => d.Status == Enum.EmployeeStatus.NotReceived || d.Status == null).ToList();
                                if (lstNotReceived.Count > 0)
                                {
                                    ExcelWorksheet ws = xls.Workbook.Worksheets["Chưa nhận"];
                                    int row = 2;// dòng bắt đầu ghi dữ liệu
                                    foreach (var item in lstNotReceived)
                                    {
                                        ws.Cells[string.Format("A{0}", row)].Value = (row - 1);//STT
                                        ws.Cells[string.Format("B{0}", row)].Value = item.EmployeeCode;//Mã
                                        ws.Cells[string.Format("C{0}", row)].Value = item.EmployeeName;//Tên
                                        ws.Cells[string.Format("D{0}", row)].Value = item.Section;//Bộ phận
                                        ws.Cells[string.Format("E{0}", row)].Value = item.Department;//Phòng ban
                                        ws.Cells[string.Format("F{0}", row)].Value = item.Union;//Công đoàn
                                        ws.Cells[string.Format("G{0}", row)].Value = !string.IsNullOrEmpty(item.Birthday) ? item.Birthday.ToString() : "";//Ngày sinh
                                        ws.Cells[string.Format("H{0}", row)].Value = item.Company;//Nhà máy nhận quà
                                        row++;
                                    }
                                }

                                //Có quẹt như ko có trong DS nhận
                                List<Employee> lstNotInReceivedList = lst.Where(d => d.Status == Enum.EmployeeStatus.NotInReceivedList).ToList();
                                if (lstNotInReceivedList.Count > 0)
                                {
                                    ExcelWorksheet ws = xls.Workbook.Worksheets["Ko có trong DS"];
                                    int row = 2;// dòng bắt đầu ghi dữ liệu
                                    foreach (var item in lstNotInReceivedList)
                                    {
                                        ws.Cells[string.Format("A{0}", row)].Value = (row - 1);//STT
                                        ws.Cells[string.Format("B{0}", row)].Value = item.EmployeeCode;//Mã
                                        ws.Cells[string.Format("C{0}", row)].Value = (item.ReceivedTime != null && item.ReceivedTime != DateTime.MinValue) ? item.ReceivedTime.ToString("HH:mm:ss - dd/MM/yyyy") : "Null";//Thời gian đã quét mã vạch
                                        ws.Cells[string.Format("D{0}", row)].Value = item.Company;//Nhà máy đã quét mã vạch
                                        ws.Cells[string.Format("E{0}", row)].Value = item.Times;//Vượt quá lần quẹt
                                        row++;
                                    }
                                }

                                xls.Save();
                            }
                        }
                    }
                }
                Process.Start(AppDomain.CurrentDomain.BaseDirectory + "/" + filename);
                dgvNotReceived.Focus();//trick: để bắt sk keypreview quét barcode
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        DateTime _lastKeystroke = new DateTime(0);
        List<char> _barcode = new List<char>(10);

        /// <summary>
        /// SK quét mã thẻ
        /// </summary>
        private void frmMain_KeyPress(object sender, KeyPressEventArgs e)
        {
            // check timing (keystrokes within 100 ms)
            TimeSpan elapsed = (DateTime.Now - _lastKeystroke);
            if (elapsed.TotalMilliseconds > 100)
                _barcode.Clear();

            // record keystroke & timestamp
            _barcode.Add(e.KeyChar);
            _lastKeystroke = DateTime.Now;

            // process barcode
            if (e.KeyChar == 13 && _barcode.Count > 0)
            {
                txtSearch.Text = "";
                string msg = new String(_barcode.ToArray());
                //lblResult.Text = msg;
                ShowInfoEmployeeAfterChecked(msg);
                _barcode.Clear();
            }
        }

        /// <summary>
        /// Hiển thị thông tin nhân viên theo mã vạch đc check và cập nhập dữ liệu vào DB
        /// <param name="sEmployeeCode">Mã nhân viên</param>
        /// </summary>
        private void ShowInfoEmployeeAfterChecked(string sEmployeeCode)
        {
            sEmployeeCode = sEmployeeCode.Trim();
            if (!string.IsNullOrEmpty(sEmployeeCode))
            {
                try
                {
                    var employee = DataProvider.GetObjectData<Employee>("dbo.Proc_GetEmployeeByID", new object[] { sEmployeeCode, company });
                    DateTime timeNow = DateTime.Now;
                    if (employee != null && !string.IsNullOrEmpty(employee.EmployeeCode))
                    {
                        lblEmployeeCodeAndName.Text = employee.EmployeeCode + " - " + employee.EmployeeName;
                        lblEmployeeCodeAndName.Visible = true;
                        lblEmployeeInfo.Text = "Bộ phận: " + employee.Section +
                                                "\nPhòng ban: " + employee.Department +
                                                "\nCông đoàn: " + employee.Union;
                        lblEmployeeInfo.Visible = true;
                        lblResult.Visible = true;

                        if (!string.IsNullOrEmpty(employee.Company) && employee.Company.ToLower() == company.ToLower())
                        {
                            //Check đã nhận quà chưa
                            if (employee.Status == Enum.EmployeeStatus.Received)
                            {
                                //Đã nhận => NG
                                lblResult.Text = "NG";
                                lblResult.BackColor = System.Drawing.Color.Red;

                                PlayResultSound(Enum.SoundType.NG);

                                if (employee.ReceivedTime != null)
                                {
                                    lblReason.Text = "Đã nhận lúc: " + ((employee.ReceivedTime != null && employee.ReceivedTime != DateTime.MinValue) ? employee.ReceivedTime.ToString("HH:mm:ss - dd/MM/yyyy") : "");
                                    lblReason.ForeColor = System.Drawing.Color.Red;
                                    lblReason.Visible = true;
                                }

                                //Lưu vào DB check lần này (lưu dồn vào trường Times)
                                if (string.IsNullOrEmpty(employee.Times))
                                {
                                    employee.Times = employee.ReceivedTime.ToString("HH:mm:ss - dd/MM/yyyy");
                                }
                                DataProvider.ExecuteNonQueryByQuerySQL("Update Employee Set Times = '" + employee.Times + ", " + timeNow.ToString("HH:mm:ss - dd/MM/yyyy") + "' where EmployeeCode = '" + employee.EmployeeCode + "' and Company = '" + company + "'");
                            }
                            else if (employee.Status == Enum.EmployeeStatus.NotReceived)
                            {
                                //Chưa nhận => update thành đã nhận
                                bool result = DataProvider.ExecuteNonQueryByQuerySQL("Update Employee Set Status = 1, ReceivedTime = '" + timeNow + "' where EmployeeCode = '" + employee.EmployeeCode + "' and Company = '" + company + "'");
                                if (result)
                                {
                                    lblResult.Text = "OK";
                                    lblResult.BackColor = System.Drawing.Color.Green;

                                    lblReason.Text = timeNow.ToString("HH:mm:ss - dd/MM/yyyy");
                                    lblReason.ForeColor = System.Drawing.Color.Green;
                                    lblReason.Visible = true;

                                    PlayResultSound(Enum.SoundType.OK);
                                }
                                else
                                {
                                    lblResult.Text = "ERROR";
                                    lblResult.BackColor = System.Drawing.Color.Red;

                                    lblReason.Text = "Lỗi lưu vào DB";
                                    lblReason.ForeColor = System.Drawing.Color.Red;
                                    lblReason.Visible = true;

                                    PlayResultSound(Enum.SoundType.NG);
                                }
                            }
                            else if (employee.Status == Enum.EmployeeStatus.NotInReceivedList)
                            {
                                //Ko có trong danh sách
                                lblEmployeeCodeAndName.Text = "Không có dữ liệu cho " + sEmployeeCode;
                                lblEmployeeCodeAndName.Visible = true;

                                lblEmployeeInfo.Visible = false;

                                lblReason.Text = "Không có trong danh sách " + company;
                                lblReason.ForeColor = System.Drawing.Color.Red;
                                lblReason.Visible = true;

                                lblResult.Text = "NG";
                                lblResult.BackColor = System.Drawing.Color.Red;

                                PlayResultSound(Enum.SoundType.NG);

                                //Lưu vào DB check lần này (lưu dồn vào trường Times)
                                if (string.IsNullOrEmpty(employee.Times))
                                {
                                    employee.Times = employee.ReceivedTime.ToString("HH:mm:ss - dd/MM/yyyy");
                                }
                                DataProvider.ExecuteNonQueryByQuerySQL("Update Employee Set Times = '" + employee.Times + ", " + timeNow.ToString("HH:mm:ss - dd/MM/yyyy") + "' where EmployeeCode = '" + employee.EmployeeCode + "' and Company = '" + company + "'");
                            }
                        }
                        else
                        {
                            //Ko thuộc nhà máy
                            lblResult.Text = "NG";
                            lblResult.BackColor = System.Drawing.Color.Red;

                            lblReason.Text = "Không thuộc " + company;
                            lblReason.ForeColor = System.Drawing.Color.Red;
                            lblReason.Visible = true;

                            PlayResultSound(Enum.SoundType.NG);
                        }
                    }
                    else
                    {
                        //Ko có trong danh sách
                        lblEmployeeCodeAndName.Text = "Không có dữ liệu cho " + sEmployeeCode;
                        lblEmployeeCodeAndName.Visible = true;

                        lblEmployeeInfo.Visible = false;

                        lblReason.Text = "Không có trong danh sách " + company;
                        lblReason.ForeColor = System.Drawing.Color.Red;
                        lblReason.Visible = true;

                        lblResult.Text = "NG";
                        lblResult.BackColor = System.Drawing.Color.Red;

                        PlayResultSound(Enum.SoundType.NG);

                        //Lưu vào db
                        bool result = DataProvider.ExecuteNonQueryByQuerySQL("Insert into Employee (EmployeeCode, ReceivedTime, [Status], Company) Values ('" + sEmployeeCode + "','" + timeNow + "','" + (int)Enum.EmployeeStatus.NotInReceivedList + "','" + company + "')");
                    }

                    RefreshData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    PlayResultSound(Enum.SoundType.NG);
                }
            }
        }

        /// <summary>
        /// Phát âm thanh kết quả
        /// <paramref name="typeResult"/>Kiểu dữ liệu âm thanh: 0 - NG, 1 - OK
        /// </summary>
        private void PlayResultSound(Enum.SoundType soundType)
        {
            if (soundType == Enum.SoundType.OK)
            {
                System.Media.SoundPlayer player = new System.Media.SoundPlayer("Sounds/OK.wav");
                player.Load();
                player.Play();
            }
            else
            {
                System.Media.SoundPlayer player = new System.Media.SoundPlayer("Sounds/NG.wav");
                player.Load();
                player.Play();
            }
        }
    }
}
