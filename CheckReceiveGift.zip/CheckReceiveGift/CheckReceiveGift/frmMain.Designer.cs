﻿namespace CheckReceiveGift
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.btnExport = new System.Windows.Forms.Button();
            this.lblFileName = new System.Windows.Forms.Label();
            this.lblCompany = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.lblProgress = new System.Windows.Forms.Label();
            this.dgvNotReceived = new System.Windows.Forms.DataGridView();
            this.dgvReceived = new System.Windows.Forms.DataGridView();
            this.lblNotReceived = new System.Windows.Forms.Label();
            this.lblReceived = new System.Windows.Forms.Label();
            this.btnImportEmployee = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblResult = new System.Windows.Forms.Label();
            this.lblEmployeeInfo = new System.Windows.Forms.Label();
            this.lblReason = new System.Windows.Forms.Label();
            this.lblEmployeeCodeAndName = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.lblVersion = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNotReceived)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReceived)).BeginInit();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnExport
            // 
            this.btnExport.BackColor = System.Drawing.Color.LimeGreen;
            this.btnExport.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnExport.ForeColor = System.Drawing.Color.White;
            this.btnExport.Location = new System.Drawing.Point(241, 8);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(222, 39);
            this.btnExport.TabIndex = 1;
            this.btnExport.TabStop = false;
            this.btnExport.Text = "Xuất danh sách chưa/đã nhận quà";
            this.btnExport.UseVisualStyleBackColor = false;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // lblFileName
            // 
            this.lblFileName.AutoSize = true;
            this.lblFileName.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblFileName.Location = new System.Drawing.Point(12, 50);
            this.lblFileName.Name = "lblFileName";
            this.lblFileName.Size = new System.Drawing.Size(60, 14);
            this.lblFileName.TabIndex = 3;
            this.lblFileName.Text = "lblFileName";
            this.lblFileName.Visible = false;
            // 
            // lblCompany
            // 
            this.lblCompany.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblCompany.BackColor = System.Drawing.Color.Transparent;
            this.lblCompany.Font = new System.Drawing.Font("Arial", 33.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblCompany.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblCompany.Location = new System.Drawing.Point(1088, 1);
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.Size = new System.Drawing.Size(159, 55);
            this.lblCompany.TabIndex = 4;
            this.lblCompany.Text = "MD";
            this.lblCompany.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.lblCompany.Visible = false;
            // 
            // progressBar1
            // 
            this.progressBar1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBar1.Location = new System.Drawing.Point(1060, 758);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(174, 10);
            this.progressBar1.TabIndex = 5;
            this.progressBar1.Visible = false;
            // 
            // lblProgress
            // 
            this.lblProgress.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblProgress.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblProgress.Location = new System.Drawing.Point(981, 756);
            this.lblProgress.Name = "lblProgress";
            this.lblProgress.Size = new System.Drawing.Size(77, 12);
            this.lblProgress.TabIndex = 6;
            this.lblProgress.Text = "0/0";
            this.lblProgress.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblProgress.Visible = false;
            // 
            // dgvNotReceived
            // 
            this.dgvNotReceived.AllowUserToAddRows = false;
            this.dgvNotReceived.AllowUserToDeleteRows = false;
            this.dgvNotReceived.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNotReceived.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvNotReceived.Location = new System.Drawing.Point(3, 24);
            this.dgvNotReceived.Name = "dgvNotReceived";
            this.dgvNotReceived.ReadOnly = true;
            this.dgvNotReceived.Size = new System.Drawing.Size(606, 368);
            this.dgvNotReceived.TabIndex = 7;
            // 
            // dgvReceived
            // 
            this.dgvReceived.AllowUserToAddRows = false;
            this.dgvReceived.AllowUserToDeleteRows = false;
            this.dgvReceived.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReceived.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvReceived.Location = new System.Drawing.Point(618, 24);
            this.dgvReceived.Margin = new System.Windows.Forms.Padding(6, 3, 3, 3);
            this.dgvReceived.Name = "dgvReceived";
            this.dgvReceived.ReadOnly = true;
            this.dgvReceived.Size = new System.Drawing.Size(603, 368);
            this.dgvReceived.TabIndex = 8;
            // 
            // lblNotReceived
            // 
            this.lblNotReceived.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblNotReceived.AutoSize = true;
            this.lblNotReceived.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblNotReceived.Location = new System.Drawing.Point(3, 2);
            this.lblNotReceived.Name = "lblNotReceived";
            this.lblNotReceived.Padding = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.lblNotReceived.Size = new System.Drawing.Size(74, 19);
            this.lblNotReceived.TabIndex = 9;
            this.lblNotReceived.Text = "Chưa nhận";
            // 
            // lblReceived
            // 
            this.lblReceived.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblReceived.AutoSize = true;
            this.lblReceived.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblReceived.ForeColor = System.Drawing.Color.ForestGreen;
            this.lblReceived.Location = new System.Drawing.Point(615, 2);
            this.lblReceived.Name = "lblReceived";
            this.lblReceived.Padding = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.lblReceived.Size = new System.Drawing.Size(58, 19);
            this.lblReceived.TabIndex = 10;
            this.lblReceived.Text = "Đã nhận";
            // 
            // btnImportEmployee
            // 
            this.btnImportEmployee.BackColor = System.Drawing.Color.OrangeRed;
            this.btnImportEmployee.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnImportEmployee.ForeColor = System.Drawing.Color.White;
            this.btnImportEmployee.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnImportEmployee.Location = new System.Drawing.Point(15, 8);
            this.btnImportEmployee.Name = "btnImportEmployee";
            this.btnImportEmployee.Size = new System.Drawing.Size(220, 39);
            this.btnImportEmployee.TabIndex = 0;
            this.btnImportEmployee.TabStop = false;
            this.btnImportEmployee.Text = "Nhập danh sách người nhận quà";
            this.btnImportEmployee.UseVisualStyleBackColor = false;
            this.btnImportEmployee.Click += new System.EventHandler(this.btnImportEmployee_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.OrangeRed;
            this.btnSearch.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnSearch.ForeColor = System.Drawing.Color.White;
            this.btnSearch.Location = new System.Drawing.Point(241, 327);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(113, 33);
            this.btnSearch.TabIndex = 12;
            this.btnSearch.TabStop = false;
            this.btnSearch.Text = "Tìm kiếm";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.txtSearch.Location = new System.Drawing.Point(12, 329);
            this.txtSearch.MaxLength = 30;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(220, 29);
            this.txtSearch.TabIndex = 11;
            this.txtSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSearch_KeyDown);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRefresh.BackColor = System.Drawing.Color.LimeGreen;
            this.btnRefresh.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnRefresh.ForeColor = System.Drawing.Color.White;
            this.btnRefresh.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRefresh.Location = new System.Drawing.Point(1117, 323);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(116, 37);
            this.btnRefresh.TabIndex = 13;
            this.btnRefresh.TabStop = false;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lblResult);
            this.panel1.Controls.Add(this.lblEmployeeInfo);
            this.panel1.Controls.Add(this.lblReason);
            this.panel1.Controls.Add(this.lblEmployeeCodeAndName);
            this.panel1.Location = new System.Drawing.Point(255, 76);
            this.panel1.MaximumSize = new System.Drawing.Size(700, 220);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(700, 220);
            this.panel1.TabIndex = 14;
            // 
            // lblResult
            // 
            this.lblResult.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblResult.Font = new System.Drawing.Font("Arial", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblResult.ForeColor = System.Drawing.Color.White;
            this.lblResult.Location = new System.Drawing.Point(307, 163);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(82, 44);
            this.lblResult.TabIndex = 3;
            this.lblResult.Text = "lblResult";
            this.lblResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblResult.Visible = false;
            // 
            // lblEmployeeInfo
            // 
            this.lblEmployeeInfo.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblEmployeeInfo.Location = new System.Drawing.Point(3, 58);
            this.lblEmployeeInfo.Name = "lblEmployeeInfo";
            this.lblEmployeeInfo.Size = new System.Drawing.Size(692, 68);
            this.lblEmployeeInfo.TabIndex = 2;
            this.lblEmployeeInfo.Text = "lblEmployeeInfo";
            this.lblEmployeeInfo.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lblEmployeeInfo.Visible = false;
            // 
            // lblReason
            // 
            this.lblReason.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblReason.ForeColor = System.Drawing.Color.Red;
            this.lblReason.Location = new System.Drawing.Point(6, 137);
            this.lblReason.Name = "lblReason";
            this.lblReason.Size = new System.Drawing.Size(687, 21);
            this.lblReason.TabIndex = 1;
            this.lblReason.Text = "lblReason";
            this.lblReason.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblReason.Visible = false;
            // 
            // lblEmployeeCodeAndName
            // 
            this.lblEmployeeCodeAndName.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblEmployeeCodeAndName.Location = new System.Drawing.Point(3, 15);
            this.lblEmployeeCodeAndName.Name = "lblEmployeeCodeAndName";
            this.lblEmployeeCodeAndName.Size = new System.Drawing.Size(692, 32);
            this.lblEmployeeCodeAndName.TabIndex = 0;
            this.lblEmployeeCodeAndName.Text = "lblEmployeeCodeAndName";
            this.lblEmployeeCodeAndName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblEmployeeCodeAndName.Visible = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.lblReceived, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.dgvNotReceived, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblNotReceived, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.dgvReceived, 1, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 361);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.316456F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 94.68355F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1224, 395);
            this.tableLayoutPanel1.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(11, 309);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 15);
            this.label1.TabIndex = 16;
            this.label1.Text = "Nhập Mã hoặc Tên";
            // 
            // lblVersion
            // 
            this.lblVersion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblVersion.AutoSize = true;
            this.lblVersion.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblVersion.Location = new System.Drawing.Point(12, 757);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(47, 12);
            this.lblVersion.TabIndex = 17;
            this.lblVersion.Text = "SDVN 1.0";
            this.lblVersion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1248, 770);
            this.Controls.Add(this.lblVersion);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.lblProgress);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.lblCompany);
            this.Controls.Add(this.lblFileName);
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.btnImportEmployee);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MinimumSize = new System.Drawing.Size(1200, 760);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Nhận quà Tết - SDVN";
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.frmMain_KeyPress);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNotReceived)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReceived)).EndInit();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnImportEmployee;
        private System.Windows.Forms.Button btnExport;
        private System.Windows.Forms.Label lblFileName;
        private System.Windows.Forms.Label lblCompany;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label lblProgress;
        private System.Windows.Forms.DataGridView dgvNotReceived;
        private System.Windows.Forms.DataGridView dgvReceived;
        private System.Windows.Forms.Label lblNotReceived;
        private System.Windows.Forms.Label lblReceived;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Label lblEmployeeInfo;
        private System.Windows.Forms.Label lblReason;
        private System.Windows.Forms.Label lblEmployeeCodeAndName;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblVersion;
    }
}

