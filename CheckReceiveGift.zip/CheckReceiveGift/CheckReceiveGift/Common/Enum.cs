﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckReceiveGift
{
    /// <summary>
    /// Enum
    /// </summary>
    public class Enum
    {
        /// <summary>
        /// Kiểu lấy danh sách nhân viên
        /// </summary>
        public enum EmployeeStatus
        {
            /// <summary>
            /// Chưa nhận
            /// </summary>
            NotReceived = 0,

            /// <summary>
            /// Đã nhận
            /// </summary>
            Received = 1,

            /// <summary>
            /// Ko có trong danh sách nhận
            /// </summary>
            NotInReceivedList = 2,

            /// <summary>
            /// Lấy tất cả
            /// </summary>
            All = 3 
        }

        /// <summary>
        /// Âm thanh thông báo kết quả
        /// </summary>
        public enum SoundType
        {
            /// <summary>
            /// NG
            /// </summary>
            NG = 0,

            /// <summary>
            /// OK
            /// </summary>
            OK = 1,
        }
    }
}
