﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CheckReceiveGift
{
    public class ConnectionHelper : IDisposable
    {
        #region Declare

        //Chuỗi kết nối database
        private readonly string _connectionString = Utilitis.GetConnectionString("conn");
        //kết nối database
        public SqlConnection Conn;

        #endregion Declare

        #region contructer

        /// <summary>
        /// Khởi tạo connection truyền vào conection string
        /// </summary>
        /// <param name="conectionString">chuỗi kết nối</param>
        /// Created by: NTSON - 16/12/2022
        public ConnectionHelper([Optional] string connectionString)
        {
            if (!string.IsNullOrEmpty(connectionString))
            {
                Conn = new SqlConnection(connectionString);
            }
            else
            {
                Conn = new SqlConnection(_connectionString);
            }
            if (Conn.State != System.Data.ConnectionState.Open)
            {
                Conn.Open();
            }
        }

        #endregion

        /// <summary>
        /// Hàm hủy đóng chuỗi kết nối
        /// </summary>
        /// Created by: NTSON - 16/12/2022
        public void Dispose()
        {
            if (Conn.State != System.Data.ConnectionState.Closed)
            {
                Conn.Close();
            }
            Conn.Dispose();
        }
    }
}
