﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Runtime.InteropServices;
using System.Reflection;

namespace CheckReceiveGift
{
    /// <summary>
    /// Các hàm tương tác database
    /// </summary>
    /// Created by: NTSON - 16/12/2022
    public class DataProvider
    {
        /// <summary>
        /// Hàm Thực hiện một store chỉ trả về số dòng ảnh hưởng (insert, update, delete)
        /// </summary>
        /// <param name="storeName">tên store</param>
        /// <param name="objParam">Các biến truyền vào</param>
        /// <returns>true: thành công</returns>
        /// Created by: NTSON - 16/12/2022
        public static bool ExecuteNonQueryByProcedure(string storeName, object objParam, [Optional] string sConnection, [Optional] SqlTransaction ts)
        {
            var result = 0;

            if (!string.IsNullOrEmpty(storeName))
            {
                var objType = objParam == null ? null : objParam.GetType();
                PropertyInfo pi = null;

                SqlConnection conn = new ConnectionHelper(sConnection).Conn;

                var cmd = new SqlCommand(storeName, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                if (ts != null)
                {
                    cmd.Transaction = ts;
                }
                SqlCommandBuilder.DeriveParameters(cmd);
                try
                {
                    int iParameters = cmd.Parameters.Count;
                    if (iParameters > 1 && objType != null)
                    {
                        for (int i = 1; i < iParameters; i++)
                        {
                            string propetyName = cmd.Parameters[i].ParameterName.Replace("@", "");
                            pi = objType.GetProperty(propetyName);
                            if (pi != null)
                            {
                                if ((pi.GetValue(objParam, null) == null))
                                {
                                    cmd.Parameters[i].Value = DBNull.Value;
                                }
                                else
                                {
                                    cmd.Parameters[i].Value = pi.GetValue(objParam, null);
                                }
                            }
                        }
                    }

                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    //ghi log
                    //CommonFunctionLogging.HandleException(ex);
                    throw ex;
                }

                finally
                {
                    if (conn.State != System.Data.ConnectionState.Closed)
                    {
                        conn.Close();
                        conn.Dispose();
                    }
                }
            }

            return result > 0;
        }

        /// <summary>
        /// Hàm Thực hiện một câu lệnh SQL chỉ trả về số dòng ảnh hưởng (insert, update, delete)
        /// </summary>
        /// <param name="querySQL">tên store</param>
        /// <returns>true: thành công</returns
        /// Created by: NTSON - 16/12/2022
        public static bool ExecuteNonQueryByQuerySQL(string querySQL, [Optional] string sConnection, [Optional] SqlTransaction ts)
        {
            var result = 0;
            if (!string.IsNullOrEmpty(querySQL))
            {
                SqlConnection conn = new ConnectionHelper(sConnection).Conn;
                try
                {
                    var cmd = new SqlCommand(querySQL, conn);
                    cmd.CommandType = CommandType.Text;
                    if (ts != null)
                    {
                        cmd.Transaction = ts;
                    }
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    //ghi log
                    //CommonFunctionLogging.HandleException(ex);
                    throw ex;
                }

                finally
                {
                    if (conn.State != System.Data.ConnectionState.Closed)
                    {
                        conn.Close();
                        conn.Dispose();
                    }
                }
            }

            return result > 0;
        }

        /// <summary>
        /// Hàm thực hiện lấy về một danh sách kết quả
        /// </summary>
        /// <param name="storeName">Tên store</param>
        /// <param name="param">Tham số đầu vào store</param>
        /// <returns>danh sách kết quả</returns>
        /// Created by: NTSON - 16/12/2022
        public static List<T> ExcuteReader<T>(string storeName, object[] param)
        {
            var result = new List<T>();
            using (var mainBaseDL = new ConnectionHelper())
            {
                var cmd = new SqlCommand(storeName, mainBaseDL.Conn);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlCommandBuilder.DeriveParameters(cmd);
                try
                {
                    int countParamInStore = cmd.Parameters.Count;
                    if (countParamInStore > 1 && param != null && param.Length > 0)
                    {
                        for (int i = 1; i < countParamInStore; i++)
                        {
                            if (i <= param.Length)
                            {
                                cmd.Parameters[i].Value = param[i - 1] != null ? param[i - 1] : DBNull.Value;
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                    var sqlDataReader = cmd.ExecuteReader();

                    //chuyển dữ liệu về list obj
                    while (sqlDataReader.Read())
                    {
                        var obj = Activator.CreateInstance<T>();
                        for (int i = 0; i < sqlDataReader.FieldCount; i++)
                        {
                            string fieldName = sqlDataReader.GetName(i);
                            if (obj.GetType().GetProperty(fieldName) != null && sqlDataReader[fieldName] != DBNull.Value)
                            {
                                obj.GetType().GetProperty(fieldName).SetValue(obj, sqlDataReader[fieldName], null);
                            }
                        }
                        result.Add(obj);
                    }
                }
                catch (Exception ex)
                {
                    //ghi log
                    //CommonFunctionLogging.HandleException(ex);
                    throw ex;
                }
            }
            return result;
        }

        /// <summary>
        /// Hàm lấy về một giá trị trong database
        /// </summary>
        /// <param name="storeName">tên store</param>
        /// <param name="param">các tham số truyền vào</param>
        /// <returns></returns>
        /// Created by: NTSON - 16/12/2022
        public object ExecuteScalar(string storeName, object[] param, [Optional] SqlTransaction ts)
        {
            var result = new object();
            using (var oConnectionHelper = new ConnectionHelper())
            {
                var cmd = new SqlCommand(storeName, oConnectionHelper.Conn);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlCommandBuilder.DeriveParameters(cmd);

                if (ts != null)
                {
                    oConnectionHelper.Conn.BeginTransaction();
                }

                try
                {
                    int iParameters = cmd.Parameters.Count;
                    if (param != null && param.Length > 0 && iParameters > 1)
                    {
                        for (int i = 1; i < iParameters; i++)
                        {
                            if (i <= param.Length)
                            {
                                cmd.Parameters[i].Value = param[i - 1] != null ? param[i - 1] : DBNull.Value;
                            }
                            else
                            {
                                break;
                            }
                        }
                    }

                    result = cmd.ExecuteScalar();

                    if (ts != null)
                    {
                        ts.Commit();
                    }

                    //transaction.Commit();
                }
                catch (Exception ex)
                {
                    //transaction.Rollback();
                    //ghi log
                    if (ts != null)
                    {
                        ts.Rollback();
                    }
                    //CommonFunctionLogging.HandleException(ex);
                    throw ex;
                }
            }
            return result;
        }

        /// <summary>
        /// Hàm Thực hiện một store chỉ trả về số dòng ảnh hưởng (insert, update, delete)
        /// </summary>
        /// <param name="storeName">tên store</param>
        /// <param name="param">Các biến truyền vào</param>
        /// <returns>số dòng ảnh hưởng</returns>
        /// Created by: NTSON - 16/12/2022
        public virtual int ExecuteNonQuery(string storeName, object[] lstParameters, [Optional] string sConnection, [Optional] SqlTransaction ts)
        {
            var result = 0;
            SqlConnection conn = new ConnectionHelper(sConnection).Conn;

            var cmd = new SqlCommand(storeName, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            if (ts != null)
            {
                cmd.Transaction = ts;
            }
            SqlCommandBuilder.DeriveParameters(cmd);
            try
            {
                int iParameters = cmd.Parameters.Count;
                if (lstParameters != null && lstParameters.Length > 0 && iParameters > 1)
                {
                    for (int i = 1; i < iParameters; i++)
                    {
                        if (lstParameters.Length >= i)
                        {
                            cmd.Parameters[i].Value = lstParameters[i - 1] != null ? lstParameters[i - 1] : DBNull.Value;
                        }
                        else
                        {
                            break;
                        }
                    }
                }
                result = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //ghi log
                //CommonFunctionLogging.HandleException(ex);
                throw ex;
            }
            finally
            {
                if (conn.State != System.Data.ConnectionState.Closed)
                {
                    conn.Close();
                    conn.Dispose();
                }
            }

            return result;
        }

        /// <summary>
        /// Hàm thực hiện lấy về một đối tượng từ database
        /// </summary>
        /// <param name="storeName">tên store</param>
        /// <param name="param">các tham số đầu vào</param>
        /// <returns>đối tượng T</returns>
        /// Created by: NTSON - 16/12/2022
        public static T GetObjectData<T>(string storeName, object[] param)
        {
            //chuyển dữ liệu obj (lấy row đầu tiên)
            T obj = Activator.CreateInstance<T>();

            using (var mainBaseDL = new ConnectionHelper())
            {
                var cmd = new SqlCommand(storeName, mainBaseDL.Conn);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlCommandBuilder.DeriveParameters(cmd);
                try
                {
                    int countParamInStore = cmd.Parameters.Count;
                    if (countParamInStore > 1 && param != null && param.Length > 0)
                    {
                        for (int i = 1; i < countParamInStore; i++)
                        {
                            if (i <= param.Length)
                            {
                                cmd.Parameters[i].Value = param[i - 1] != null ? param[i - 1] : DBNull.Value;
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                    var sqlDataReader = cmd.ExecuteReader();
                    while (sqlDataReader.Read())
                    {
                        for (int i = 0; i < sqlDataReader.FieldCount; i++)
                        {
                            string fieldName = sqlDataReader.GetName(i);
                            if (obj.GetType().GetProperty(fieldName) != null && sqlDataReader[fieldName] != DBNull.Value)
                            {
                                obj.GetType().GetProperty(fieldName).SetValue(obj, sqlDataReader[fieldName], null);
                            }
                        }

                        // thoát vòng lặp khi đọc xong dòng đầu
                        break;
                    }
                }
                catch (Exception ex)
                {
                    //ghi log
                    //CommonFunctionLogging.HandleException(ex);
                    throw ex;
                }
            }
            return obj;
        }

        /// <summary>
        /// Hàm gọi store lấy về một trang danh sách
        /// </summary>
        /// <typeparam name="T">Đối tượng cần lấy trang danh sách</typeparam>
        /// <param name="storeName">Tên Store</param>
        /// <param name="pageIndex">Trang cần lấy</param>
        /// <param name="pageSize">Số bản ghi trên một trang</param>
        /// <param name="where">Điều kiện tìm kiếm</param>
        /// <param name="sort">Điều kiện sắp xếp</param>
        /// <param name="sConnection">Connection nếu muốn kết nối tới DB không phải mặc định</param>
        /// <returns>Trang danh sách cần lấy</returns>
        /// Created by: NTSON - 16/12/2022
        //public Paging<T> GetPaging<T>(string storeName, int pageIndex, int pageSize, string where, string sort, [Optional] string sConnection)
        //{
        //    var result = new Paging<T>();
        //    SqlConnection conn = new ConnectionHelper(sConnection).Conn;
        //    //SqlConnection conn;
        //    //if (string.IsNullOrEmpty(sConnection))
        //    //{
        //    //    conn = new ConnectionHelperDL().Conn;
        //    //}
        //    //else
        //    //{
        //    //    conn = new ConnectionHelperDL(sConnection).Conn;
        //    //}

        //    var cmd = new SqlCommand(storeName, conn);
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    int totalRecord = 0;

        //    try
        //    {
        //        cmd.Parameters.AddWithValue("@PageIndex", pageIndex);
        //        cmd.Parameters.AddWithValue("@PageSize", pageSize);
        //        cmd.Parameters.AddWithValue("@Where", where);
        //        cmd.Parameters.AddWithValue("@Sort", sort);
        //        cmd.Parameters.Add("@TotalRecord", SqlDbType.Int);
        //        cmd.Parameters["@TotalRecord"].Direction = ParameterDirection.Output;

        //        using (var sqlDataReader = cmd.ExecuteReader())
        //        {
        //            //chuyển dữ liệu về list obj
        //            result.Items = new List<T>();
        //            while (sqlDataReader.Read())
        //            {
        //                var obj = Activator.CreateInstance<T>();
        //                for (int i = 0; i < sqlDataReader.FieldCount; i++)
        //                {
        //                    string fieldName = sqlDataReader.GetName(i);
        //                    if (obj.GetType().GetProperty(fieldName) != null && sqlDataReader[fieldName] != DBNull.Value)
        //                    {
        //                        obj.GetType().GetProperty(fieldName).SetValue(obj, sqlDataReader[fieldName], null);
        //                    }
        //                }
        //                result.Items.Add(obj);
        //            }
        //        }

        //        if (cmd.Parameters["@TotalRecord"].Value != null)
        //        {
        //            int.TryParse(cmd.Parameters["@TotalRecord"].Value.ToString(), out totalRecord);
        //        }
        //        result.TotalRecord = totalRecord;
        //    }
        //    catch (Exception ex)
        //    {
        //        //ghi log
        //        //CommonFunctionLogging.HandleException(ex);
        //        throw ex;
        //    }
        //    finally
        //    {
        //        if (conn.State != System.Data.ConnectionState.Closed)
        //        {
        //            conn.Close();
        //            conn.Dispose();
        //        }
        //    }

        //    return result;
        //}
    }
}
