﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckReceiveGift
{
    /// <summary>
    /// Lớp này chứa các hàm sử dụng chung
    /// </summary>
    /// Created by: NTSON - 16/12/2022
    public class Utilitis
    {
        /// <summary>
        /// Hàm lấy kết nối database
        /// </summary>
        /// <returns>chuỗi kêt nối</returns>
        /// Created by: NTSON - 16/12/2022
        public static string GetConnectionString(string keyConnection)
        {
            return ConfigurationManager.ConnectionStrings[keyConnection].ConnectionString;
        }

        /// <summary>
        /// Thực hiện lấy key trong appseting
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        /// Created by: NTSON - 16/12/2022
        public static string GetAppSetingKeys(string key)
        {
            return ConfigurationManager.AppSettings[key];
        }

        /// <summary>
        /// Loại bỏ SQL Injection
        /// Dùng cho toán tử Equal
        /// </summary>
        /// <param name="inputSQL">đầu vào</param>
        /// <returns>Chuỗi đã được loại bỏ Injection</returns>
        /// Created by: NTSON - 16/12/2022
        public static string SafeSqlLiteralEqual(string inputSQL)
        {
            inputSQL = inputSQL.Replace("'", "''");

            return inputSQL;
        }

        /// <summary>
        /// Loại bỏ sql injection
        /// Dùng cho toán tử LIKE
        /// </summary>
        /// <param name="inputSQL">đầu vào</param>
        /// <returns>Chuỗi đã được loại bỏ Injection</returns>
        /// Created by: NTSON - 16/12/2022
        public static string SafeSqlLiteralLike(string inputSQL)
        {
            inputSQL = inputSQL.Replace("'", "''");
            inputSQL = inputSQL.Replace("[", "[[]");
            inputSQL = inputSQL.Replace("%", "[%]");
            inputSQL = inputSQL.Replace("_", "[_]");

            return inputSQL;
        }
    }
}
